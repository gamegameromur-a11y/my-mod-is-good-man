package com.chameleon.mixin;

import com.chameleon.client.WhiteSkinManager;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Third-person render effects, driven entirely by role + pose:
 *
 *  NONE   -> nothing changes: original skin, original size, no pose rotation
 *  HIDER  -> small (1/2.34x) + painted/white skin + whole-body pose rotation
 *  SEEKER -> normal size + painted/white skin + whole-body pose rotation
 *
 * V0.1.2 - BUG #2 FIX (broken poses):
 *   Previously, PlayerModelMixin rotated individual body parts (head, body,
 *   arms, legs) independently around their own vanilla pivots. Because those
 *   pivots are designed for a STANDING biped, rotating body.pitch by 90
 *   degrees (etc.) made the parts visually separate from each other - gaps
 *   opened up between limbs and the torso, and the whole model floated in
 *   mid-air instead of lying on the ground.
 *
 *   The fix moves the heavy rotation to THIS class, where the whole model is
 *   rotated and translated as one rigid object (matrices.translate +
 *   matrices.multiply on the shared MatrixStack) before any individual body
 *   part is drawn. PlayerModelMixin now only adds small limb adjustments on
 *   top of an already-correctly-oriented body, which is what removes the
 *   "gaps" between body parts.
 *
 * V0.1.2 - IMPROVEMENT #1 FIX (gap against the wall):
 *   WALL_HUG no longer relies on bending body parts backward (which left a
 *   visible gap between the model and the wall). Instead the whole model is
 *   nudged backward along its facing direction by WALL_HUG_NUDGE, which
 *   visually presses the character flat against whatever is behind them.
 */
@Environment(EnvType.CLIENT)
@Mixin(PlayerEntityRenderer.class)
public class PlayerRendererMixin {

    /** Shrinks HIDER players to roughly 43% of normal size. */
    private static final float CHAMELEON_SCALE = 1f / 2.34f;

    // -- Pose rotation pivot/offset constants (in blocks) -----------------------
    // Tweak these if a pose still looks slightly off in-game; they are kept as
    // separate named constants specifically so they're easy to nudge.
    private static final float ROTATE_PIVOT_Y   = 0.95f; // waist-height pivot for rotation
    private static final float GROUND_DROP_FULL  = 0.80f; // lying flat (prone/side/fetal)
    private static final float GROUND_DROP_CROUCH= 0.35f; // custom crouch (partial bend)
    private static final float WALL_HUG_NUDGE     = 0.28f; // push back into the wall

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(AbstractClientPlayerEntity player, float yaw, float tickDelta,
                              MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                              int light, CallbackInfo ci) {

        RoleManager.Role role = RoleManager.getRole(player.getUuid());
        if (role == RoleManager.Role.NONE) {
            // No changes at all for normal players.
            return;
        }

        if (role == RoleManager.Role.HIDER) {
            // Scale from the feet (origin) so the feet stay planted on the ground.
            matrices.scale(CHAMELEON_SCALE, CHAMELEON_SCALE, CHAMELEON_SCALE);
        }

        applyPoseTransform(matrices, PlayerPaintStore.getPose(player.getUuid()));
        // Fine limb adjustments happen afterwards in PlayerModelMixin#setAngles.
    }

    /**
     * Rotates/translates the WHOLE player model as a single rigid body so that
     * every limb moves together - this is what keeps the body looking like one
     * connected character instead of disjointed floating parts.
     */
    private void applyPoseTransform(MatrixStack matrices, ChameleonPose pose) {
        switch (pose) {
            case STAND -> { /* no transform */ }

            case PRONE -> {
                // Lying face-down: rotate the whole body forward onto the ground.
                matrices.translate(0.0, ROTATE_PIVOT_Y, 0.0);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90f));
                matrices.translate(0.0, -ROTATE_PIVOT_Y, 0.0);
                matrices.translate(0.0, -GROUND_DROP_FULL, 0.0);
            }

            case SIDE_LAY -> {
                // Lying on the side: rotate around the depth axis.
                matrices.translate(0.0, ROTATE_PIVOT_Y, 0.0);
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(90f));
                matrices.translate(0.0, -ROTATE_PIVOT_Y, 0.0);
                matrices.translate(0.0, -GROUND_DROP_FULL, 0.0);
            }

            case CROUCH_CUSTOM -> {
                // Partial forward lean - body stays upright-ish, just hunched.
                matrices.translate(0.0, ROTATE_PIVOT_Y, 0.0);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(35f));
                matrices.translate(0.0, -ROTATE_PIVOT_Y, 0.0);
                matrices.translate(0.0, -GROUND_DROP_CROUCH, 0.0);
            }

            case FETAL -> {
                // Curled into a ball, low to the ground.
                matrices.translate(0.0, ROTATE_PIVOT_Y, 0.0);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(70f));
                matrices.translate(0.0, -ROTATE_PIVOT_Y, 0.0);
                matrices.translate(0.0, -GROUND_DROP_FULL, 0.0);
            }

            case WALL_HUG -> {
                // Stays upright, but is nudged backward into whatever wall the
                // player is facing away from - this removes the visible gap
                // between the model and the wall (Improvement #1).
                matrices.translate(0.0, 0.0, -WALL_HUG_NUDGE);
            }
        }
    }

    /**
     * Skin texture is overridden ONLY for HIDER or SEEKER. NONE keeps the
     * player's real skin.
     *
     * (This override also covers first-person rendering, since
     * renderRightArm/renderLeftArm below call this same getTexture() method
     * internally - kept here for the third-person path and as a second line
     * of defense alongside FirstPersonSkinMixin, which patches
     * AbstractClientPlayerEntity#getSkinTexture() directly.)
     */
    @Inject(
        method = "getTexture(Lnet/minecraft/client/network/AbstractClientPlayerEntity;)Lnet/minecraft/util/Identifier;",
        at = @At("RETURN"),
        cancellable = true
    )
    private void overrideSkinTexture(AbstractClientPlayerEntity player,
                                     CallbackInfoReturnable<Identifier> cir) {

        RoleManager.Role role = RoleManager.getRole(player.getUuid());
        if (role == RoleManager.Role.NONE) return;

        PaintData data = PlayerPaintStore.getPaint(player.getUuid());
        Identifier dynamicId = WhiteSkinManager.getTexture(player.getUuid(), data);
        cir.setReturnValue(dynamicId);
    }

    /**
     * V0.1.2 - BUG #3 FIX (POV showed normal size): renderRightArm/
     * renderLeftArm are the methods HeldItemRenderer actually calls to draw
     * the first-person arm - render() (where the HIDER scale is applied
     * above) is NEVER called in first-person view, which is why the arm
     * always looked normal-sized regardless of role. Applying the same
     * scale here makes a HIDER's first-person arm shrink along with their
     * third-person body.
     */
    @Inject(method = "renderRightArm", at = @At("HEAD"))
    private void onRenderRightArm(MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                   int light, AbstractClientPlayerEntity player, CallbackInfo ci) {
        applyFirstPersonArmScale(matrices, player);
    }

    @Inject(method = "renderLeftArm", at = @At("HEAD"))
    private void onRenderLeftArm(MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                  int light, AbstractClientPlayerEntity player, CallbackInfo ci) {
        applyFirstPersonArmScale(matrices, player);
    }

    private void applyFirstPersonArmScale(MatrixStack matrices, AbstractClientPlayerEntity player) {
        if (RoleManager.isHider(player.getUuid())) {
            matrices.scale(CHAMELEON_SCALE, CHAMELEON_SCALE, CHAMELEON_SCALE);
        }
    }
}
