package com.chameleon.mixin;

import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Controls nametag visibility based on role.
 *
 * Rules:
 *   SEEKER -> HIDER   : nametag HIDDEN
 *   SEEKER -> SEEKER  : visible
 *   HIDER  -> anyone  : visible
 *   NO ROLE -> anyone : normal behavior (visible)
 */
@Environment(EnvType.CLIENT)
@Mixin(EntityRenderer.class)
public class EntityRendererMixin {

    @Inject(method = "renderLabelIfPresent",
            at = @At("HEAD"),
            cancellable = true)
    private void chameleonHideNametag(Entity entity,
                                      Text text,
                                      MatrixStack matrices,
                                      VertexConsumerProvider vertexConsumers,
                                      int light,
                                      CallbackInfo ci) {

        // Only relevant for player entities.
        if (!(entity instanceof PlayerEntity)) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        RoleManager.Role viewerRole = RoleManager.getRole(client.player.getUuid());
        RoleManager.Role targetRole = RoleManager.getRole(entity.getUuid());

        // Seekers can't see hiders' nametags.
        if (viewerRole == RoleManager.Role.SEEKER && targetRole == RoleManager.Role.HIDER) {
            ci.cancel();
        }
        // Every other combination renders normally.
    }
}
