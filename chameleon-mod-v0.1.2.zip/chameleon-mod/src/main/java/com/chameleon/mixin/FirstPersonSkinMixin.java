package com.chameleon.mixin;

import com.chameleon.client.WhiteSkinManager;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * V0.1.2 - BUG #3 FIX (first-person view shows the wrong skin and size).
 *
 * AbstractClientPlayerEntity#getSkinTexture() is the single source every
 * render path ultimately asks for the player's skin: third-person
 * (PlayerEntityRenderer, already overridden separately in
 * PlayerRendererMixin for safety/back-compat), the player list head icon,
 * AND first-person view (HeldItemRenderer reads the skin straight off the
 * player entity rather than going through PlayerEntityRenderer).
 *
 * By overriding it here too, the painted/white skin now shows up in POV as
 * well, not just in third person. Players with role NONE are completely
 * unaffected - getSkinTexture() returns the original value untouched.
 */
@Environment(EnvType.CLIENT)
@Mixin(AbstractClientPlayerEntity.class)
public class FirstPersonSkinMixin {

    @Inject(method = "getSkinTexture", at = @At("RETURN"), cancellable = true)
    private void chameleonOverrideSkin(CallbackInfoReturnable<Identifier> cir) {
        AbstractClientPlayerEntity self = (AbstractClientPlayerEntity)(Object) this;

        RoleManager.Role role = RoleManager.getRole(self.getUuid());
        if (role == RoleManager.Role.NONE) return;

        PaintData data = PlayerPaintStore.getPaint(self.getUuid());
        cir.setReturnValue(WhiteSkinManager.getTexture(self.getUuid(), data));
    }
}
