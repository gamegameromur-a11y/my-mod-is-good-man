package com.chameleon.mixin;

import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fine limb adjustments layered ON TOP of the whole-body rotation that
 * PlayerRendererMixin already applies to the MatrixStack.
 *
 * V0.1.2 - BUG #2 FIX: this class used to do ALL of the heavy lifting
 * (rotating body.pitch by +/-90 degrees etc.) using each limb's own vanilla
 * pivot. That produced gaps between limbs because vanilla pivots are tuned
 * for a standing biped, not a body lying flat. Now that PlayerRendererMixin
 * rotates the entire model as a single rigid object first, this class only
 * needs to add small, natural-looking limb bends - arms tucked in, legs
 * slightly bent, etc. - which keeps every part visually attached to the
 * torso in every pose.
 *
 * This mixin only affects the third-person model (PlayerEntityModel). First-
 * person view does not call setAngles on this model at all - the first-
 * person arm is rendered through PlayerEntityRenderer#renderRightArm/
 * renderLeftArm, a completely separate code path - which is why POV size and
 * skin are handled separately (see FirstPersonSkinMixin and the
 * renderRightArm/renderLeftArm injections in PlayerRendererMixin).
 */
@Environment(EnvType.CLIENT)
@Mixin(PlayerEntityModel.class)
public class PlayerModelMixin {

    @Shadow public ModelPart head;
    @Shadow public ModelPart body;
    @Shadow public ModelPart rightArm;
    @Shadow public ModelPart leftArm;
    @Shadow public ModelPart rightLeg;
    @Shadow public ModelPart leftLeg;
    @Shadow public ModelPart hat;

    /**
     * Injected after setAngles so the vanilla animation runs first and we
     * layer our adjustments on top (instead of being overwritten by it).
     */
    @Inject(
        method = "setAngles(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFFFF)V",
        at = @At("RETURN")
    )
    private void applyCustomPose(AbstractClientPlayerEntity entity,
                                  float limbAngle, float limbDistance,
                                  float animProgress, float headYaw, float headPitch,
                                  CallbackInfo ci) {

        RoleManager.Role role = RoleManager.getRole(entity.getUuid());
        if (role == RoleManager.Role.NONE) return;

        ChameleonPose pose = PlayerPaintStore.getPose(entity.getUuid());
        if (pose == ChameleonPose.STAND) return;

        resetAll();

        switch (pose) {
            case PRONE         -> applyProne();
            case SIDE_LAY      -> applySideLay();
            case CROUCH_CUSTOM -> applyCrouchCustom(headPitch);
            case FETAL         -> applyFetal();
            case WALL_HUG      -> applyWallHug(headPitch);
            default -> { }
        }
    }

    private void resetAll() {
        head.pitch = 0; head.yaw = 0; head.roll = 0;
        body.pitch = 0; body.yaw = 0; body.roll = 0;
        rightArm.pitch = 0; rightArm.roll = 0; rightArm.yaw = 0;
        leftArm.pitch  = 0; leftArm.roll  = 0; leftArm.yaw  = 0;
        rightLeg.pitch = 0; rightLeg.roll = 0;
        leftLeg.pitch  = 0; leftLeg.roll  = 0;
        // Hat reset independently - copying head's transform tends to
        // double up the pivot offset.
        hat.pitch = 0; hat.yaw = 0; hat.roll = 0;
    }

    /** Lying face-down: arms tucked forward, legs together and slightly bent. */
    private void applyProne() {
        rightArm.pitch = rad(95);  rightArm.roll = rad(-8);
        leftArm.pitch  = rad(95);  leftArm.roll  = rad( 8);
        rightLeg.pitch = rad(-6);
        leftLeg.pitch  = rad(-6);
        head.pitch     = rad(-12);
        hat.pitch       = head.pitch;
    }

    /** Lying on the side: arms relaxed against the body, legs slightly bent. */
    private void applySideLay() {
        rightArm.roll = rad(-12); rightArm.pitch = rad(6);
        leftArm.roll  = rad( 12); leftArm.pitch  = rad(6);
        rightLeg.roll = rad(-8);  rightLeg.pitch = rad(8);
        leftLeg.roll  = rad( 8);  leftLeg.pitch  = rad(4);
        head.roll      = rad(-4);
        hat.roll        = head.roll;
    }

    /** Custom crouch: hunched forward, arms and legs bent inward. */
    private void applyCrouchCustom(float headPitch) {
        body.pitch     = rad(10);
        rightArm.pitch = rad(20); rightArm.roll = rad( 8);
        leftArm.pitch  = rad(20); leftArm.roll  = rad(-8);
        rightLeg.pitch = rad(28);
        leftLeg.pitch  = rad(28);
        head.pitch     = rad(-8) + headPitch * 0.3f;
        hat.pitch       = head.pitch;
    }

    /** Curled into a ball: limbs pulled in tightly. */
    private void applyFetal() {
        rightArm.pitch = rad(60);  rightArm.roll = rad( 20);
        leftArm.pitch  = rad(60);  leftArm.roll  = rad(-20);
        rightLeg.pitch = rad(85);  rightLeg.roll = rad( 10);
        leftLeg.pitch  = rad(85);  leftLeg.roll  = rad(-10);
        head.pitch     = rad(35);
        hat.pitch       = head.pitch;
    }

    /** Flat against a wall: arms pressed close to the sides. */
    private void applyWallHug(float headPitch) {
        rightArm.pitch = rad(-4); rightArm.roll = rad(10);
        leftArm.pitch  = rad(-4); leftArm.roll  = rad(-10);
        rightLeg.pitch = rad(0);
        leftLeg.pitch  = rad(0);
        head.pitch     = headPitch * 0.5f;
        hat.pitch       = head.pitch;
    }

    private static float rad(float deg) { return (float) Math.toRadians(deg); }
}
