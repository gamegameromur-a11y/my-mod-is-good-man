package com.chameleon.mixin;

import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.role.RoleManager;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ServerPlayerEntity mixin:
 *
 *  - NBT persist:
 *      readCustomDataFromNbt  -> load Chameleon data
 *      writeCustomDataToNbt   -> save Chameleon data
 *
 *  - Damage immunity for HIDER (V0.1.2 FIX - BUG #1):
 *      damage()           -> HIDER takes damage ONLY from arrows. Every other
 *                             damage type (fall, fire, explosion, drowning,
 *                             starvation, potions, mob attacks, melee, etc.)
 *                             is cancelled outright.
 *      handleFallDamage    -> kept as a defensive secondary guard, since some
 *                             fall-damage code paths can bypass damage() on
 *                             certain server versions.
 *
 *  - Cleanup on disconnect:
 *      onDisconnect           -> remove server-side data
 *
 *  NOTE: Join-time sync happens in ChameleonMod's ServerPlayConnectionEvents.JOIN
 *        event rather than onSpawn, since onSpawn is not called on reconnect.
 */
@Mixin(ServerPlayerEntity.class)
public class PlayerEntityMixin {

    // -- NBT: Load --------------------------------------------------------------

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onLoadNbt(NbtCompound nbt, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        if (nbt.contains("ChameleonData")) {
            PlayerPaintStore.loadPlayer(self.getUuid(), nbt.getCompound("ChameleonData"));
        }
    }

    // -- NBT: Save ----------------------------------------------------------------

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onSaveNbt(NbtCompound nbt, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        nbt.put("ChameleonData", PlayerPaintStore.savePlayer(self.getUuid()));
    }

    // -- Damage immunity for HIDER (V0.1.2 - BUG #1 FIX) -------------------------

    /**
     * HIDER players only take damage from arrows (bow/crossbow projectiles).
     * Every other damage source - fall, fire, lava, explosions, drowning,
     * starvation, potions of harming, melee attacks, magic, etc. - is
     * cancelled completely so the "1/2 heart, one hit and you're out" design
     * isn't accidentally triggered by the environment.
     */
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void chameleonFilterDamage(DamageSource source, float amount,
                                        CallbackInfoReturnable<Boolean> cir) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        if (RoleManager.isHider(self.getUuid()) && !source.isOf(DamageTypes.ARROW)) {
            cir.setReturnValue(false);
            cir.cancel();
        }
    }

    // -- Fall damage secondary guard ----------------------------------------------

    /**
     * Defensive backstop: fall damage is already blocked above by
     * chameleonFilterDamage (fall damage source is not DamageTypes.ARROW),
     * but handleFallDamage can in some cases run through a separate code
     * path, so it is cancelled here too for HIDER players.
     */
    @Inject(method = "handleFallDamage", at = @At("HEAD"), cancellable = true)
    private void preventFallDamageForHider(float fallDistance, float damageMultiplier,
                                           DamageSource source,
                                           CallbackInfoReturnable<Boolean> cir) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        if (RoleManager.isHider(self.getUuid())) {
            cir.setReturnValue(false);
            cir.cancel();
        }
    }

    // -- Cleanup on leave -----------------------------------------------------------

    @Inject(method = "onDisconnect", at = @At("TAIL"))
    private void onPlayerLeave(CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        // Server-side data cleanup.
        // Client-side texture cleanup is handled by ChameleonMod's PLAYER_LEAVE packet.
        PlayerPaintStore.remove(self.getUuid());
        RoleManager.remove(self.getUuid());
    }
}
