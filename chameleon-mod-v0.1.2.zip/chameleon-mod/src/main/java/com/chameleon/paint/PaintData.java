package com.chameleon.paint;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIntArray;

import java.util.Arrays;

/**
 * Holds a player's paint data.
 * The character is divided into a 32x64 grid of cells (matching the Steve
 * texture's proportions). Each cell is an ARGB color int.
 * Default color: white (0xFFFFFFFF).
 */
public class PaintData {

    public static final int GRID_W = 32;
    public static final int GRID_H = 64;
    public static final int CELL_COUNT = GRID_W * GRID_H;

    // ARGB color of each cell - defaults to white.
    private final int[] cells;

    public PaintData() {
        cells = new int[CELL_COUNT];
        Arrays.fill(cells, 0xFFFFFFFF); // fully white
    }

    private PaintData(int[] cells) {
        this.cells = cells;
    }

    /** Gets the color of a single cell. */
    public int getCell(int x, int y) {
        if (x < 0 || x >= GRID_W || y < 0 || y >= GRID_H) return 0xFFFFFFFF;
        return cells[y * GRID_W + x];
    }

    /**
     * Paints with a circular brush centered on the given cell.
     * radius: in cells (1-10 recommended).
     */
    public void paintBrush(int centerX, int centerY, int radius, int argbColor) {
        for (int dy = -radius; dy <= radius; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                if (dx * dx + dy * dy <= radius * radius) {
                    int cx = centerX + dx;
                    int cy = centerY + dy;
                    if (cx >= 0 && cx < GRID_W && cy >= 0 && cy < GRID_H) {
                        cells[cy * GRID_W + cx] = argbColor;
                    }
                }
            }
        }
    }

    /** Resets all paint back to white. */
    public void reset() {
        Arrays.fill(cells, 0xFFFFFFFF);
    }

    /** Saves to NBT (used for server->client sync and persistence). */
    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        nbt.put("cells", new NbtIntArray(cells));
        return nbt;
    }

    /** Loads from NBT. */
    public static PaintData fromNbt(NbtCompound nbt) {
        if (nbt.contains("cells")) {
            int[] loaded = nbt.getIntArray("cells");
            if (loaded.length == CELL_COUNT) {
                return new PaintData(loaded.clone());
            }
        }
        return new PaintData();
    }

    /** Raw int array for sending over the network. */
    public int[] getRawCells() {
        return cells.clone();
    }

    /** Builds from a raw array (received over the network). */
    public static PaintData fromRaw(int[] raw) {
        if (raw.length != CELL_COUNT) return new PaintData();
        return new PaintData(raw.clone());
    }
}
