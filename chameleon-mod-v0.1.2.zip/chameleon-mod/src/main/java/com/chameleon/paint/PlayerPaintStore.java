package com.chameleon.paint;

import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.RoleManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Holds each player's paint data, pose, and (via savePlayer/loadPlayer)
 * persists their role too, so leaving and rejoining a server doesn't reset
 * a player back to role NONE.
 */
public class PlayerPaintStore {

    private static final Map<UUID, PaintData>     paintMap = new ConcurrentHashMap<>();
    private static final Map<UUID, ChameleonPose> poseMap  = new ConcurrentHashMap<>();

    // -- Paint ----------------------------------------------------------------

    public static PaintData getPaint(PlayerEntity player) {
        return paintMap.computeIfAbsent(player.getUuid(), k -> new PaintData());
    }

    public static PaintData getPaint(UUID uuid) {
        return paintMap.computeIfAbsent(uuid, k -> new PaintData());
    }

    public static void setPaint(UUID uuid, PaintData data) { paintMap.put(uuid, data); }

    // -- Pose -------------------------------------------------------------------

    public static ChameleonPose getPose(PlayerEntity player) {
        return poseMap.getOrDefault(player.getUuid(), ChameleonPose.STAND);
    }

    public static ChameleonPose getPose(UUID uuid) {
        return poseMap.getOrDefault(uuid, ChameleonPose.STAND);
    }

    public static void setPose(UUID uuid, ChameleonPose pose) { poseMap.put(uuid, pose); }

    // -- Cleanup ------------------------------------------------------------------

    public static void remove(UUID uuid) {
        paintMap.remove(uuid);
        poseMap.remove(uuid);
    }

    // -- NBT persistence ------------------------------------------------------------

    /** Saves paint + pose + role to NBT. */
    public static NbtCompound savePlayer(UUID uuid) {
        NbtCompound nbt = new NbtCompound();
        nbt.put("paint", getPaint(uuid).toNbt());
        nbt.putInt("pose", getPose(uuid).id);
        nbt.putInt("role", RoleManager.getRole(uuid).id);
        return nbt;
    }

    /** Loads paint + pose + role from NBT. */
    public static void loadPlayer(UUID uuid, NbtCompound nbt) {
        if (nbt.contains("paint")) setPaint(uuid, PaintData.fromNbt(nbt.getCompound("paint")));
        if (nbt.contains("pose"))  setPose(uuid, ChameleonPose.byId(nbt.getInt("pose")));
        if (nbt.contains("role"))  RoleManager.setRole(uuid, RoleManager.Role.byId(nbt.getInt("role")));
    }
}
