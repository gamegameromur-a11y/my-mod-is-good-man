package com.chameleon.role;

import com.chameleon.network.ChameleonNetwork;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Commands:
 *   /cham role hider   - Become a Hider (1/2 heart, no fall damage)
 *   /cham role seeker  - Become a Seeker (Power V + Infinity bow + 1 arrow)
 *   /cham role none    - Return to normal mode (skin and size reset)
 */
public class ChameleonCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
            CommandManager.literal("cham")
                .then(CommandManager.literal("role")
                    .then(CommandManager.literal("hider")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.HIDER)))
                    .then(CommandManager.literal("seeker")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.SEEKER)))
                    .then(CommandManager.literal("none")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.NONE)))
                )
        );
    }

    private static int setRole(CommandContext<ServerCommandSource> ctx,
                                RoleManager.Role newRole) {
        ServerCommandSource source = ctx.getSource();
        ServerPlayerEntity player;
        try { player = source.getPlayerOrThrow(); }
        catch (Exception e) {
            source.sendError(Text.translatable("chameleon.cmd.no_player"));
            return 0;
        }

        RoleManager.Role oldRole = RoleManager.getRole(player.getUuid());

        // Clear the old role's effects (resets size and health).
        RoleEffects.reset(player, oldRole);

        // Store the new role and apply its effects.
        RoleManager.setRole(player.getUuid(), newRole);
        RoleEffects.apply(player, newRole);

        // Notify every client (for nametag + skin + render).
        broadcastRoleSync(player, newRole);

        // Chat feedback for the player.
        player.sendMessage(
            Text.translatable("chameleon.cmd.role.set",
                Text.translatable("chameleon.role." + newRole.name().toLowerCase())),
            false);
        return 1;
    }

    /** Sends a SYNC_ROLE packet to every client. */
    public static void broadcastRoleSync(ServerPlayerEntity changed, RoleManager.Role role) {
        if (changed.getServer() == null) return;
        changed.getServer().getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(changed.getUuid());
            buf.writeInt(role.id);
            ServerPlayNetworking.send(p, ChameleonNetwork.SYNC_ROLE, buf);
        });
    }
}
