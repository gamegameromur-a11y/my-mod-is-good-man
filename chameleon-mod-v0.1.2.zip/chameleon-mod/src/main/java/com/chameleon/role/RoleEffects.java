package com.chameleon.role;

import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Applies/removes the gameplay effects tied to each role.
 *
 * Duplicate-item guard: apply(SEEKER) only grants a Power V bow if the
 * player doesn't already have an enchanted bow, and only tops up arrows if
 * they have none - calling /cham role seeker more than once does not stack
 * up extra bows/arrows.
 */
public final class RoleEffects {

    private RoleEffects() {}

    public static void apply(ServerPlayerEntity player, RoleManager.Role role) {
        switch (role) {
            case HIDER -> {
                EntityAttributeInstance maxHp =
                        player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
                if (maxHp != null) maxHp.setBaseValue(1.0);
                player.setHealth(1.0f);
            }
            case SEEKER -> {
                // Check whether the inventory already has an enchanted bow.
                boolean hasPowerBow = false;
                boolean hasArrow    = false;
                for (int i = 0; i < player.getInventory().size(); i++) {
                    ItemStack stack = player.getInventory().getStack(i);
                    if (!stack.isEmpty()) {
                        if (stack.isOf(Items.BOW) && stack.getEnchantments().getSize() > 0)
                            hasPowerBow = true;
                        if (stack.isOf(Items.ARROW))
                            hasArrow = true;
                    }
                }
                // Grant a bow only if they don't have one yet.
                if (!hasPowerBow) {
                    ItemStack bow = new ItemStack(Items.BOW);
                    bow.addEnchantment(Enchantments.POWER,    5);
                    bow.addEnchantment(Enchantments.INFINITY, 1);
                    if (!player.getInventory().insertStack(bow))
                        player.dropItem(bow, false);
                }
                // Top up arrows only if they have none.
                if (!hasArrow) {
                    ItemStack arrow = new ItemStack(Items.ARROW, 1);
                    if (!player.getInventory().insertStack(arrow))
                        player.dropItem(arrow, false);
                }
            }
            default -> { }
        }
    }

    public static void reset(ServerPlayerEntity player, RoleManager.Role oldRole) {
        if (oldRole == RoleManager.Role.HIDER) {
            EntityAttributeInstance maxHp =
                    player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
            if (maxHp != null) maxHp.setBaseValue(20.0);
            player.setHealth(20.0f);
        }
    }
}
