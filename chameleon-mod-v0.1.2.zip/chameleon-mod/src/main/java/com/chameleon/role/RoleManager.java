package com.chameleon.role;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages player roles.
 * Used on both server and client; client sync happens via the SYNC_ROLE
 * packet.
 *
 * Roles:
 *   NONE   - Normal play, no role
 *   HIDER  - Hider: 1/2 heart HP, no fall damage, seekers can't see their nametag
 *   SEEKER - Seeker: gets a Power V bow, can't see hiders' nametags
 */
public class RoleManager {

    public enum Role {
        NONE  (0, "Normal"),
        HIDER (1, "Hider"),
        SEEKER(2, "Seeker");

        public final int    id;
        public final String displayName;

        Role(int id, String displayName) {
            this.id = id;
            this.displayName = displayName;
        }

        public static Role byId(int id) {
            for (Role r : values()) if (r.id == id) return r;
            return NONE;
        }
    }

    private static final Map<UUID, Role> roleMap = new ConcurrentHashMap<>();

    public static Role getRole(UUID uuid)         { return roleMap.getOrDefault(uuid, Role.NONE); }
    public static void setRole(UUID uuid, Role r)  { roleMap.put(uuid, r); }
    public static void remove(UUID uuid)           { roleMap.remove(uuid); }

    public static boolean isHider (UUID uuid) { return getRole(uuid) == Role.HIDER;  }
    public static boolean isSeeker(UUID uuid) { return getRole(uuid) == Role.SEEKER; }
}
