package com.chameleon.network;

import com.chameleon.ChameleonMod;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Network packets:
 *
 *  C->S  PAINT_STROKE  : brush stroke (cx, cy, radius, color)
 *  C->S  POSE_CHANGE   : pose change (poseId)
 *  S->C  SYNC_PAINT    : full paint data (uuid + int[])
 *  S->C  SYNC_POSE     : pose sync (uuid + poseId)
 *  S->C  SYNC_ROLE     : role sync (uuid + roleId)
 *  S->C  PLAYER_LEAVE  : player left, clean up texture (uuid)
 */
public class ChameleonNetwork {

    // Packet identifiers
    public static final Identifier PAINT_STROKE  = new Identifier(ChameleonMod.MOD_ID, "paint_stroke");
    public static final Identifier POSE_CHANGE   = new Identifier(ChameleonMod.MOD_ID, "pose_change");
    public static final Identifier SYNC_PAINT    = new Identifier(ChameleonMod.MOD_ID, "sync_paint");
    public static final Identifier SYNC_POSE     = new Identifier(ChameleonMod.MOD_ID, "sync_pose");
    public static final Identifier SYNC_ROLE     = new Identifier(ChameleonMod.MOD_ID, "sync_role");
    public static final Identifier PLAYER_LEAVE  = new Identifier(ChameleonMod.MOD_ID, "player_leave");

    public static void registerServerPackets() {

        // -- C->S: Brush stroke -----------------------------------------------
        // The server always uses the SENDER's own UUID, so a player can never
        // write into someone else's paint data.
        ServerPlayNetworking.registerGlobalReceiver(PAINT_STROKE,
                (server, player, handler, buf, responseSender) -> {
                    int cx     = buf.readInt();
                    int cy     = buf.readInt();
                    int radius = buf.readInt();
                    int color  = buf.readInt();

                    server.execute(() -> {
                        // UUID comes from the packet sender - painting someone
                        // else's data is impossible.
                        PaintData data = PlayerPaintStore.getPaint(player);
                        data.paintBrush(cx, cy, radius, color);
                        broadcastPaintSync(player.getUuid(), data, handler);
                    });
                });

        // -- C->S: Pose change --------------------------------------------------
        ServerPlayNetworking.registerGlobalReceiver(POSE_CHANGE,
                (server, player, handler, buf, responseSender) -> {
                    int poseId = buf.readInt();

                    server.execute(() -> {
                        ChameleonPose pose = ChameleonPose.byId(poseId);
                        PlayerPaintStore.setPose(player.getUuid(), pose);
                        broadcastPoseSync(player.getUuid(), pose, handler);
                    });
                });
    }

    // -- Broadcast helpers ----------------------------------------------------

    /**
     * Broadcasts paint data to every player.
     * Consistently uses writeIntArray, matching the client's readIntArray.
     */
    public static void broadcastPaintSync(java.util.UUID uuid, PaintData data,
                                          net.minecraft.server.network.ServerPlayNetworkHandler origin) {
        if (origin.getPlayer().getServer() == null) return;
        int[] cells = data.getRawCells();
        origin.getPlayer().getServer().getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(uuid);
            buf.writeIntArray(cells);   // writeIntArray <-> client's readIntArray
            ServerPlayNetworking.send(p, SYNC_PAINT, buf);
        });
    }

    /** Broadcasts a pose sync to every player. */
    public static void broadcastPoseSync(java.util.UUID uuid, ChameleonPose pose,
                                         net.minecraft.server.network.ServerPlayNetworkHandler origin) {
        if (origin.getPlayer().getServer() == null) return;
        origin.getPlayer().getServer().getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(uuid);
            buf.writeInt(pose.id);
            ServerPlayNetworking.send(p, SYNC_POSE, buf);
        });
    }

    /** Broadcasts a player-leave notice to every client (for texture cleanup). */
    public static void broadcastPlayerLeave(java.util.UUID uuid,
                                            net.minecraft.server.MinecraftServer server) {
        if (server == null) return;
        server.getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(uuid);
            ServerPlayNetworking.send(p, PLAYER_LEAVE, buf);
        });
    }

    // -- Packet builders (used for JOIN sync) ----------------------------------

    /** Builds a SYNC_PAINT packet. */
    public static PacketByteBuf buildSyncPaintPacket(java.util.UUID uuid, PaintData data) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(uuid);
        buf.writeIntArray(data.getRawCells());
        return buf;
    }

    /** Builds a SYNC_POSE packet. */
    public static PacketByteBuf buildSyncPosePacket(java.util.UUID uuid, ChameleonPose pose) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(uuid);
        buf.writeInt(pose.id);
        return buf;
    }

    /** Builds a SYNC_ROLE packet. */
    public static PacketByteBuf buildSyncRolePacket(java.util.UUID uuid,
                                                    com.chameleon.role.RoleManager.Role role) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(uuid);
        buf.writeInt(role.id);
        return buf;
    }
}
