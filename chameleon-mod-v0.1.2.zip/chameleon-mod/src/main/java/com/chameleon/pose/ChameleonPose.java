package com.chameleon.pose;

/**
 * The 6 poses a player can take.
 * Each pose has different pitch/yaw/scale and joint angles for rendering.
 */
public enum ChameleonPose {

    STAND(0, "Stand"),          // default, upright stance
    PRONE(1, "Lie Down"),       // lying face-down
    SIDE_LAY(2, "Lie on Side"), // lying on the side
    CROUCH_CUSTOM(3, "Crouch"), // custom crouch, different from vanilla
    FETAL(4, "Curl Up"),        // fetal position - curled into a ball
    WALL_HUG(5, "Hug Wall");    // pressed flat against a wall

    public final int id;
    public final String displayName;

    ChameleonPose(int id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public static ChameleonPose byId(int id) {
        for (ChameleonPose p : values()) {
            if (p.id == id) return p;
        }
        return STAND;
    }

    public ChameleonPose next() {
        ChameleonPose[] vals = values();
        return vals[(this.ordinal() + 1) % vals.length];
    }

    public ChameleonPose previous() {
        ChameleonPose[] vals = values();
        return vals[(this.ordinal() - 1 + vals.length) % vals.length];
    }
}
