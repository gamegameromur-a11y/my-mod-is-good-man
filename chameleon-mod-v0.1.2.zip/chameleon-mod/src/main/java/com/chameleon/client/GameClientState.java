package com.chameleon.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/**
 * Game state held on the client.
 * Updated by GAME_STATE, GAME_RESULT, and PLAYER_CAUGHT packets coming
 * from the server.
 */
@Environment(EnvType.CLIENT)
public class GameClientState {

    /** Current game phase ID (matches GameState.id on the server). */
    public static int   stateId      = 0;   // 0 = WAITING
    public static int   timerSeconds = 0;
    public static int   hidersAlive  = 0;
    public static int   totalHiders  = 0;
    public static String winnerText  = "";
    public static long  lastUpdate   = 0;   // System.currentTimeMillis()

    /** Current map vote list (filled in by OPEN_MAP_SELECT). */
    public static final java.util.List<String> mapNames = new java.util.ArrayList<>();
    public static final java.util.List<String> mapDescs = new java.util.ArrayList<>();

    /** Name of the last caught player, and when that notice should expire. */
    public static String caughtPlayerName = "";
    public static long   caughtAt         = 0; // millis

    // -- Helpers ------------------------------------------------------------

    public static boolean isGameActive() {
        return stateId >= 2; // COUNTDOWN and beyond
    }

    public static boolean isHidingPhase() { return stateId == 3; }
    public static boolean isSeekingPhase(){ return stateId == 4; }
    public static boolean isEnded()       { return stateId == 5; }
    public static boolean isWaiting()     { return stateId <= 1; }
}
