package com.chameleon.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Map selection screen.
 *
 * +-------------------------------------------+
 * |          MAP SELECT                       |
 * |                                           |
 * |  [  Map 1  ] [  Map 2  ] [  ?  ]          |
 * |  [  Map 4  ] [  Map 5  ] [  ?  ]          |
 * |           [  Map 7  ]                     |
 * |                                           |
 * |                            [  Close  ]    |
 * +-------------------------------------------+
 *
 * ChameleonMod opens this screen when an OPEN_MAP_SELECT packet arrives
 * from the server. Filled slots become clickable buttons; empty slots show
 * "Coming soon".
 */
@Environment(EnvType.CLIENT)
public class MapSelectScreen extends Screen {

    private static final int TOTAL_SLOTS = 7;    // Total number of map slots
    private static final int SLOT_W      = 140;
    private static final int SLOT_H      = 60;
    private static final int COLS        = 3;
    private static final int GAP         = 12;

    private final List<String> mapNames;
    private final List<String> mapDescs;
    private int hoveredSlot = -1;

    public MapSelectScreen(List<String> mapNames, List<String> mapDescs) {
        super(Text.literal("Select Map"));
        this.mapNames = mapNames;
        this.mapDescs = mapDescs;
    }

    @Override
    protected void init() {
        int startX = (this.width  - (COLS * SLOT_W + (COLS - 1) * GAP)) / 2;
        int startY = 60;

        for (int i = 0; i < TOTAL_SLOTS; i++) {
            boolean hasMap = i < mapNames.size();
            int col = i % COLS;
            int row = i / COLS;

            // Center the last row if it has fewer than COLS entries.
            int totalInRow = Math.min(COLS, TOTAL_SLOTS - row * COLS);
            int rowStartX  = (this.width - (totalInRow * SLOT_W + (totalInRow - 1) * GAP)) / 2;

            int bx = rowStartX + col * (SLOT_W + GAP);
            int by = startY + row * (SLOT_H + GAP);

            if (hasMap) {
                final String mapName = mapNames.get(i);
                addDrawableChild(ButtonWidget.builder(
                        Text.literal("\u00a7a" + mapName), btn -> voteForMap(mapName))
                        .dimensions(bx, by, SLOT_W, SLOT_H).build());
            } else {
                // Empty slot - disabled.
                addDrawableChild(ButtonWidget.builder(
                        Text.literal("\u00a77Coming soon..."), btn -> {})
                        .dimensions(bx, by, SLOT_W, SLOT_H)
                        .build());
            }
        }

        // Close button.
        addDrawableChild(ButtonWidget.builder(Text.literal("\u2715 Close"), btn -> close())
                .dimensions(this.width - 80, this.height - 30, 70, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Semi-transparent background.
        ctx.fill(0, 0, this.width, this.height, 0xAA000000);
        super.render(ctx, mouseX, mouseY, delta);

        // Title.
        ctx.drawCenteredTextWithShadow(textRenderer,
                "\u00a76\u00a7lSELECT MAP", this.width / 2, 20, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                "\u00a77Click the map you want to play",
                this.width / 2, 34, 0xAAAAAA);

        // Map descriptions (shown on hover).
        if (hoveredSlot >= 0 && hoveredSlot < mapDescs.size()) {
            String desc = mapDescs.get(hoveredSlot);
            if (!desc.isEmpty())
                ctx.drawCenteredTextWithShadow(textRenderer,
                        "\u00a77" + desc, this.width / 2, this.height - 50, 0xAAAAAA);
        }

        // Footer info.
        if (mapNames.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    "\u00a7cNo maps added yet. All 7 slots are coming soon!",
                    this.width / 2, this.height - 20, 0xFF6666);
        } else {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    "\u00a77" + mapNames.size() + "/7 maps available",
                    this.width / 2, this.height - 20, 0x888888);
        }
    }

    @Override
    public void renderBackground(DrawContext ctx) {
        // Let the in-game world show through - suppress the dirt background.
    }

    private void voteForMap(String mapName) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(mapName);
        ClientPlayNetworking.send(
                new net.minecraft.util.Identifier("chameleon", "map_vote"), buf);
        close();
    }

    @Override
    public boolean shouldPause() { return false; }
}
