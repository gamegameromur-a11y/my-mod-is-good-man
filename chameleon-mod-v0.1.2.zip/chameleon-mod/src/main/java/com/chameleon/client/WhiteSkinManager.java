package com.chameleon.client;

import com.chameleon.paint.PaintData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Builds the painted "white skin" texture for HIDER/SEEKER players.
 *
 * Layer handling (kept from the original fix): the outer layer (jacket,
 * hat, sleeves) is fully transparent so it never covers the painted inner
 * layer:
 *   1. Every pixel starts fully transparent (0x00000000)
 *   2. Only the inner-layer regions are filled with opaque white (0xFFFFFFFF)
 *   3. Paint data is written into those inner-layer regions
 *   4. Outer-layer pixels stay transparent -> inner layer is always visible
 *
 * All 6 faces (front/back/left/right/top/bottom) of every body part are
 * painted with the same grid color, not just front/back.
 *
 * V0.1.2 - BUG #3 FIX (first-person view):
 *   This class only ever produced a SEPARATE "chameleon:skin_<uuid>"
 *   Identifier, which PlayerRendererMixin substitutes in for THIRD-PERSON
 *   rendering only. First-person view (the player's own arm, rendered by
 *   HeldItemRenderer) reads the skin straight off
 *   AbstractClientPlayerEntity#getSkinTexture() and never goes through
 *   PlayerEntityRenderer#getTexture - which is why POV kept showing the
 *   player's real, unpainted skin.
 *
 *   The fix is FirstPersonSkinMixin (see that class), which overrides
 *   getSkinTexture() itself for HIDER/SEEKER players and returns this same
 *   "chameleon:skin_<uuid>" Identifier. Since first-person rendering,
 *   third-person rendering, and the player list head icon all ultimately
 *   resolve the skin through that one method (directly or via the override
 *   in PlayerEntityRenderer), a single texture now covers every view - no
 *   GPU texture swapping or backups of the player's original skin are
 *   needed, which keeps this fix simple and safe.
 */
@Environment(EnvType.CLIENT)
public class WhiteSkinManager {

    private static final Map<UUID, Identifier> textureCache = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer>    hashCache    = new ConcurrentHashMap<>();

    private static final int SKIN_W = 64;
    private static final int SKIN_H = 64;

    public static Identifier getTexture(UUID uuid, PaintData data) {
        int hash = Arrays.hashCode(data.getRawCells());
        Integer prev = hashCache.get(uuid);
        if (prev != null && prev == hash && textureCache.containsKey(uuid))
            return textureCache.get(uuid);
        return buildAndCache(uuid, data, hash);
    }

    private static Identifier buildAndCache(UUID uuid, PaintData data, int hash) {
        MinecraftClient mc = MinecraftClient.getInstance();

        NativeImage img = buildPaintedImage(data);

        Identifier id = new Identifier("chameleon",
                "skin_" + uuid.toString().replace("-", ""));
        Identifier old = textureCache.get(uuid);
        if (old != null) mc.getTextureManager().destroyTexture(old);

        mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(img));
        textureCache.put(uuid, id);
        hashCache.put(uuid, hash);
        return id;
    }

    /** Builds a fresh painted 64x64 skin image from the given paint data. */
    private static NativeImage buildPaintedImage(PaintData data) {
        NativeImage img = new NativeImage(NativeImage.Format.RGBA, SKIN_W, SKIN_H, false);

        // Step 1: every pixel starts transparent.
        for (int y = 0; y < SKIN_H; y++)
            for (int x = 0; x < SKIN_W; x++)
                img.setColor(x, y, 0x00000000);

        // Step 2: only inner-layer regions become opaque white.
        fillInnerLayers(img);

        // Step 3: paint data is applied on top of the inner layer.
        applyPaint(img, data);

        return img;
    }

    /**
     * Only the inner-layer regions get opaque white. The outer layer
     * (jacket, hat, outer arm/leg) stays transparent.
     *
     * Steve inner-layer regions (64x64 layout):
     *   Head   : x=0-32,  y=0-16
     *   Body   : x=16-40, y=16-32
     *   R.Arm  : x=40-56, y=16-32
     *   R.Leg  : x=0-16,  y=16-32
     *   L.Arm  : x=32-48, y=48-64  (1.8+ format)
     *   L.Leg  : x=16-32, y=48-64  (1.8+ format)
     */
    private static void fillInnerLayers(NativeImage img) {
        fillRect(img, 0,  0,  32, 16);  // head inner
        fillRect(img, 0,  16, 64, 16);  // body + R.arm + R.leg inner (y=16-32)
        fillRect(img, 16, 48, 32, 16);  // L.arm + L.leg inner (y=48-64)
    }

    private static void fillRect(NativeImage img, int x, int y, int w, int h) {
        for (int py = y; py < y + h; py++)
            for (int px = x; px < x + w; px++)
                img.setColor(px, py, abgr(0xFFFFFFFF));
    }

    /**
     * Writes paint data into the Steve UV inner-layer regions.
     * {skinX, skinY, skinW, skinH, gridX, gridY, gridW, gridH}
     *
     * Side faces (left/right) are included - not just front/back.
     */
    private static void applyPaint(NativeImage img, PaintData data) {

        int[][] regions = {
            // -- Head - all 6 faces --------------------------------------------
            {  8,  8,  8,  8,    0,  0,  8,  8 },  // front
            { 24,  8,  8,  8,    0,  0,  8,  8 },  // back
            { 16,  8,  8,  8,    0,  0,  8,  8 },  // right
            {  0,  8,  8,  8,    0,  0,  8,  8 },  // left
            {  8,  0,  8,  8,    0,  0,  8,  8 },  // top
            { 16,  0,  8,  8,    0,  0,  8,  8 },  // bottom

            // -- Body - all 6 faces ---------------------------------------------
            { 20, 20,  8, 12,    8,  0,  8, 12 },  // front
            { 32, 20,  8, 12,    8,  0,  8, 12 },  // back
            { 16, 20,  4, 12,    8,  0,  4, 12 },  // right
            { 28, 20,  4, 12,    8,  0,  4, 12 },  // left
            { 20, 16,  8,  4,    8,  0,  8,  4 },  // top
            { 28, 16,  8,  4,    8,  0,  8,  4 },  // bottom

            // -- Right arm - all 6 faces -----------------------------------------
            { 44, 20,  4, 12,   18,  0,  4, 12 },  // front
            { 52, 20,  4, 12,   18,  0,  4, 12 },  // back
            { 40, 20,  4, 12,   18,  0,  4, 12 },  // right
            { 48, 20,  4, 12,   18,  0,  4, 12 },  // left
            { 44, 16,  4,  4,   18,  0,  4,  4 },  // top
            { 48, 16,  4,  4,   18,  0,  4,  4 },  // bottom

            // -- Left arm (1.8+) - all 6 faces -----------------------------------
            { 36, 52,  4, 12,   22,  0,  4, 12 },  // front
            { 44, 52,  4, 12,   22,  0,  4, 12 },  // back
            { 32, 52,  4, 12,   22,  0,  4, 12 },  // right
            { 40, 52,  4, 12,   22,  0,  4, 12 },  // left
            { 36, 48,  4,  4,   22,  0,  4,  4 },  // top
            { 40, 48,  4,  4,   22,  0,  4,  4 },  // bottom

            // -- Right leg - all 6 faces ------------------------------------------
            {  4, 20,  4, 12,   18, 12,  4, 12 },  // front
            { 12, 20,  4, 12,   18, 12,  4, 12 },  // back
            {  0, 20,  4, 12,   18, 12,  4, 12 },  // right
            {  8, 20,  4, 12,   18, 12,  4, 12 },  // left
            {  4, 16,  4,  4,   18, 12,  4,  4 },  // top
            {  8, 16,  4,  4,   18, 12,  4,  4 },  // bottom

            // -- Left leg (1.8+) - all 6 faces ------------------------------------
            { 20, 52,  4, 12,   22, 12,  4, 12 },  // front
            { 28, 52,  4, 12,   22, 12,  4, 12 },  // back
            { 16, 52,  4, 12,   22, 12,  4, 12 },  // right
            { 24, 52,  4, 12,   22, 12,  4, 12 },  // left
            { 20, 48,  4,  4,   22, 12,  4,  4 },  // top
            { 24, 48,  4,  4,   22, 12,  4,  4 },  // bottom
        };

        for (int[] r : regions) {
            int sx = r[0], sy = r[1], sw = r[2], sh = r[3];
            int gx = r[4], gy = r[5], gw = r[6], gh = r[7];
            for (int py = 0; py < sh; py++) {
                for (int px = 0; px < sw; px++) {
                    int gc = Math.min(gx + (int)((float)px/sw*gw), gx+gw-1);
                    int gr = Math.min(gy + (int)((float)py/sh*gh), gy+gh-1);
                    img.setColor(sx + px, sy + py, abgr(data.getCell(gc, gr)));
                }
            }
        }
    }

    /** ARGB -> ABGR (NativeImage byte order). */
    private static int abgr(int argb) {
        int a=(argb>>24)&0xFF, r=(argb>>16)&0xFF, g=(argb>>8)&0xFF, b=argb&0xFF;
        return (a<<24)|(b<<16)|(g<<8)|r;
    }

    public static void cleanup(UUID uuid) {
        Identifier id = textureCache.remove(uuid);
        if (id != null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) mc.getTextureManager().destroyTexture(id);
        }
        hashCache.remove(uuid);
    }
}
