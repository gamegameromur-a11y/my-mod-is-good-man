package com.chameleon.client;

import com.chameleon.network.ChameleonNetwork;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;

/**
 * V0.1.2 - IMPROVEMENT #2: real 3D painting screen.
 *
 * The character preview on the left is no longer a set of flat 2D
 * rectangles - it's the player's actual 3D entity model, rendered with
 * InventoryScreen.drawEntity(...) (the same vanilla method the inventory
 * screen uses to show the player). The camera itself never moves: only the
 * MODEL rotates in place, driven by dragging on empty space. Clicking
 * directly on the character paints whatever part is under the cursor, in
 * the color currently selected on the right-hand palette.
 *
 * Interaction model:
 *   - Drag on the character itself -> paints a brush stroke (and keeps
 *     painting while the drag continues, like a real brush).
 *   - Drag on EMPTY space (anywhere else in the 3D preview area) -> spins
 *     the model left/right (and slightly up/down) so every side can be
 *     reached. This never touches the in-world camera - the screen stays a
 *     normal GUI overlay the whole time.
 *   - Scroll over the palette -> adjusts brush size.
 *
 * Hit-testing is done as fractions of the fixed preview rectangle (not raw
 * pixels tied to the model's internal render scale), which keeps it simple
 * and robust regardless of exactly how the vanilla renderer sizes the
 * model. Left/right is re-mapped automatically once the model has been
 * spun past +/-90 degrees, so painting always matches what's visually
 * facing the player.
 *
 * Every interaction here is wrapped defensively (null checks on the
 * client/player, clamped indices, try/catch around the 3D draw call) so a
 * render hiccup can never crash the screen - per the "never an error"
 * requirement.
 */
@Environment(EnvType.CLIENT)
public class PaintHudScreen extends Screen {

    // -- Layout -----------------------------------------------------------------
    private static final int SWATCH = 14;   // color swatch size, px
    private static final int COLS   = 8;    // palette columns
    private static final int TAB_H  = 12;   // tab button height

    // -- 3D preview state ---------------------------------------------------------
    private float modelYaw   = 20f;   // degrees, spun by dragging empty space
    private float modelPitch = 0f;    // degrees, slight up/down tilt (clamped)
    private boolean draggingModel = false;
    private boolean painting      = false;

    // -- Paint state --------------------------------------------------------------
    private int   currentColor = 0xFF4CAF50;
    private int   brushRadius  = 3;
    private Tab   activeTab    = Tab.MECHA;
    /** Throttle: avoid flooding the network with a packet on every dragged pixel. */
    private long lastPaintMs = 0;

    private enum Tab { MECHA, BASIC, NATURE, SKIN, PASTEL, NEON, DARK, EARTH }

    // -- Color palettes -------------------------------------------------------------
    private static final int[] MECHA = {
        0xFFFFFFFF,0xFFE0E0E0,0xFFBDBDBD,0xFF9E9E9E,0xFF757575,0xFF616161,0xFF424242,0xFF212121,
        0xFFFFCDD2,0xFFEF9A9A,0xFFE57373,0xFFEF5350,0xFFE53935,0xFFC62828,0xFF9C1010,0xFF6D0000,
        0xFFFFE0B2,0xFFFFCC80,0xFFFFB74D,0xFFFFA726,0xFFFF9800,0xFFFB8C00,0xFFE65100,0xFFBF360C,
        0xFFFFF9C4,0xFFFFF176,0xFFFFEE58,0xFFFFEB3B,0xFFFFD600,0xFFFFC107,0xFFFF8F00,0xFFFF6F00,
        0xFFF1F8E9,0xFFDCEDC8,0xFFC5E1A5,0xFFA5D6A7,0xFF81C784,0xFF66BB6A,0xFF4CAF50,0xFF388E3C,
        0xFFE0F7FA,0xFFB2EBF2,0xFF80DEEA,0xFF4DD0E1,0xFF26C6DA,0xFF00BCD4,0xFF0097A7,0xFF006064,
        0xFFE3F2FD,0xFFBBDEFB,0xFF90CAF9,0xFF64B5F6,0xFF42A5F5,0xFF2196F3,0xFF1565C0,0xFF0D47A1,
        0xFFEDE7F6,0xFFD1C4E9,0xFFB39DDB,0xFF9575CD,0xFF7E57C2,0xFF673AB7,0xFF4527A0,0xFF311B92,
        0xFFFCE4EC,0xFFF8BBD9,0xFFF48FB1,0xFFF06292,0xFFEC407A,0xFFE91E63,0xFFC2185B,0xFF880E4F,
        0xFFFFF8E1,0xFFFFECB3,0xFFFFE082,0xFFFFD54F,0xFFFFCA28,0xFFFFB300,0xFFFF8F00,0xFFFF6F00,
    };
    private static final int[] BASIC = {
        0xFFFFFFFF,0xFF000000,0xFFFF0000,0xFF00FF00,0xFF0000FF,0xFFFFFF00,0xFFFF00FF,0xFF00FFFF,
        0xFFFF8000,0xFF8000FF,0xFF008040,0xFF800040,0xFF000080,0xFF808000,0xFF008080,0xFF800080,
    };
    private static final int[] NATURE = {
        0xFF2E7D32,0xFF388E3C,0xFF43A047,0xFF4CAF50,0xFF66BB6A,0xFF81C784,0xFFA5D6A7,0xFFC8E6C9,
        0xFF1565C0,0xFF1976D2,0xFF1E88E5,0xFF42A5F5,0xFF64B5F6,0xFF90CAF9,0xFFBBDEFB,0xFFE3F2FD,
        0xFF4E342E,0xFF5D4037,0xFF6D4C41,0xFF795548,0xFF8D6E63,0xFFA1887F,0xFFBCAAA4,0xFFD7CCC8,
    };
    private static final int[] SKIN = {
        0xFFFFE0BD,0xFFFFD5B0,0xFFF5C09A,0xFFE8AD87,0xFFD4956A,0xFFC07840,0xFFA05C28,0xFF7A4018,
        0xFF6D3522,0xFF5C2D18,0xFF4A2010,0xFF3D1808,0xFFFFC8A0,0xFFFFB080,0xFFFF9868,0xFFEE8050,
    };
    private static final int[] PASTEL = {
        0xFFFFB3BA,0xFFFFCCBA,0xFFFFFFBA,0xFFBAFFBA,0xFFBAEFFF,0xFFBAC8FF,0xFFE0BAFF,0xFFFFBAEA,
        0xFFFFD9B3,0xFFD9FFB3,0xFFB3FFD9,0xFFB3EEFF,0xFFB3C8FF,0xFFD4B3FF,0xFFFFB3D4,0xFFFFF5F5,
    };
    private static final int[] NEON = {
        0xFFFF0080,0xFFFF0040,0xFFFF4000,0xFFFF8000,0xFFFFBF00,0xFFFFFF00,0xFFBFFF00,0xFF80FF00,
        0xFF00FF00,0xFF00FF80,0xFF00FFFF,0xFF00BFFF,0xFF0080FF,0xFF0040FF,0xFF8000FF,0xFFFF00FF,
    };
    private static final int[] DARK = {
        0xFF1A0A0A,0xFF2D0000,0xFF001A00,0xFF00001A,0xFF1A001A,0xFF001A1A,0xFF1A1A00,0xFF0D0D0D,
        0xFF3D0000,0xFF003D00,0xFF00003D,0xFF3D003D,0xFF003D3D,0xFF3D3D00,0xFF222222,0xFF111111,
    };
    private static final int[] EARTH = {
        0xFFF5DEB3,0xFFEDD9A3,0xFFE4C87A,0xFFD2B055,0xFFBE9A3A,0xFFB5651D,0xFFA0522D,0xFF8B4513,
        0xFF9E9E9E,0xFF757575,0xFF616161,0xFF424242,0xFF795548,0xFF6D4C41,0xFF5D4037,0xFF4E342E,
    };

    public PaintHudScreen() {
        super(Text.literal("Character Painting"));
    }

    @Override
    protected void init() {
        int px = panelX();
        Tab[] tabs = Tab.values();
        int tw = (PANEL_W() - 4) / 4, th = TAB_H;
        for (int i = 0; i < tabs.length; i++) {
            final Tab t = tabs[i];
            int bx = px + 2 + (i % 4) * tw;
            int by = 6  + (i / 4) * (th + 2);
            addDrawableChild(ButtonWidget.builder(Text.literal(tabShort(t)), btn -> {
                activeTab = t;
            }).dimensions(bx, by, tw - 1, th).build());
        }

        int toolY = this.height - 38;
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
            if (brushRadius > 1) brushRadius--;
        }).dimensions(px + 2, toolY, 22, 14).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
            if (brushRadius < 8) brushRadius++;
        }).dimensions(px + 26, toolY, 22, 14).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("\u21ba Reset"), b -> {
            getLocalData().reset();
            sendStroke(PaintData.GRID_W / 2, PaintData.GRID_H / 2, 64, 0xFFFFFFFF);
        }).dimensions(px + 52, toolY, 60, 14).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("\u2715"), b -> close())
            .dimensions(px + PANEL_W() - 22, toolY, 20, 14).build());
    }

    // -- Render -----------------------------------------------------------------

    @Override
    public void renderBackground(DrawContext ctx) {
        // Let the game world show through; only darken the side panel.
        ctx.fill(panelX() - 2, 0, this.width, this.height, 0xCC101010);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        super.render(ctx, mouseX, mouseY, delta);

        int px = panelX();

        // -- Active tab highlight -------------------------------------------
        Tab[] tabs = Tab.values();
        int tw = (PANEL_W() - 4) / 4, th = TAB_H;
        for (int i = 0; i < tabs.length; i++) {
            if (tabs[i] == activeTab) {
                int bx = px + 2 + (i % 4) * tw;
                int by = 6  + (i / 4) * (th + 2);
                ctx.drawBorder(bx - 1, by - 1, tw, th + 2, 0xFFFFD700);
            }
        }

        // -- Color palette ----------------------------------------------------
        int paletteY = 6 + 2 * (TAB_H + 2) + 6;
        int[] colors = activeColors();
        for (int i = 0; i < colors.length; i++) {
            int cx2 = px + 2 + (i % COLS) * SWATCH;
            int cy2 = paletteY + (i / COLS) * SWATCH;
            ctx.fill(cx2, cy2, cx2 + SWATCH - 1, cy2 + SWATCH - 1, colors[i]);
            if (colors[i] == currentColor)
                ctx.drawBorder(cx2 - 1, cy2 - 1, SWATCH + 1, SWATCH + 1, 0xFFFFD700);
            if (mouseX >= cx2 && mouseX < cx2 + SWATCH - 1 && mouseY >= cy2 && mouseY < cy2 + SWATCH - 1)
                ctx.drawBorder(cx2 - 1, cy2 - 1, SWATCH + 1, SWATCH + 1, 0xFFFFFFFF);
        }

        // -- Current color / brush info ----------------------------------------
        int rowsUsed = (colors.length + COLS - 1) / COLS;
        int infoY = paletteY + rowsUsed * SWATCH + 8;
        ctx.fill(px + 2, infoY, px + 2 + SWATCH, infoY + SWATCH, currentColor);
        ctx.drawBorder(px + 1, infoY - 1, SWATCH + 2, SWATCH + 2, 0xFFFFFFFF);
        ctx.drawText(textRenderer, "Brush size: " + brushRadius, px + 2 + SWATCH + 6, infoY + 3, 0xAAAAAA, false);

        // -- Left side: real 3D character preview ------------------------------
        renderCharacterPreview(ctx, mouseX, mouseY);

        // -- Hint ---------------------------------------------------------------
        ctx.drawCenteredTextWithShadow(textRenderer,
            "\u00a77Click the character to paint - drag empty space to rotate",
            panelX() / 2, this.height - 14, 0x888888);
    }

    /**
     * Draws the player's real 3D model using the same vanilla method the
     * inventory screen uses (InventoryScreen.drawEntity), with a manually
     * controlled rotation so dragging empty space spins the model exactly
     * as expected without ever touching the in-world camera.
     *
     * Wrapped in try/catch: a render-side issue here must never freeze or
     * crash the rest of the screen.
     */
    private void renderCharacterPreview(DrawContext ctx, int mouseX, int mouseY) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            AbstractClientPlayerEntity player = mc.player;
            if (player == null) return;

            PreviewArea area = previewArea();

            // Subtle panel backdrop so the model reads clearly against the world.
            ctx.fill(area.x1, area.y1, area.x2, area.y2, 0x55000000);
            ctx.drawBorder(area.x1, area.y1, area.x2 - area.x1, area.y2 - area.y1, 0x66FFFFFF);

            int centerX = (area.x1 + area.x2) / 2;
            int centerY = (area.y1 + area.y2) / 2;
            int size = Math.max(10, (area.y2 - area.y1) / 3); // fits comfortably within the panel

            Quaternionf rotation = RotationAxis.POSITIVE_Y.rotationDegrees(modelYaw)
                    .mul(RotationAxis.POSITIVE_X.rotationDegrees(modelPitch));

            // Manual-rotation overload: (context, x, y, size, rotation,
            // overrideCameraAngle, entity). Passing null for the camera
            // angle keeps the default slightly-elevated inventory-style view.
            InventoryScreen.drawEntity(ctx, centerX, centerY, size, rotation, null, player);

            highlightHoveredRegion(ctx, area, mouseX, mouseY);
        } catch (Exception e) {
            // Never let a preview hiccup take down the whole screen.
            com.chameleon.ChameleonMod.LOGGER.warn("Chameleon paint preview render error", e);
        }
    }

    /** Draws a soft highlight border tinted with the current brush color while hovering the model. */
    private void highlightHoveredRegion(DrawContext ctx, PreviewArea area, int mouseX, int mouseY) {
        if (!area.contains(mouseX, mouseY)) return;
        BodyRegion region = resolveRegion(area, mouseX, mouseY);
        if (region == null) return;
        ctx.drawBorder(area.x1, area.y1, area.x2 - area.x1, area.y2 - area.y1,
                (currentColor & 0x00FFFFFF) | 0x66000000);
    }

    // -- Mouse input --------------------------------------------------------------

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (btn != 0) return super.mouseClicked(mx, my, btn);

        if (mx >= panelX()) {
            if (handleColorPick(mx, my)) return true;
            return super.mouseClicked(mx, my, btn);
        }

        PreviewArea area = previewArea();
        if (area.contains((int) mx, (int) my)) {
            BodyRegion region = resolveRegion(area, (int) mx, (int) my);
            if (region != null) {
                painting = true;
                paintRegion(region);
                return true;
            }
        }

        // Clicked on empty space (not on the character) - start rotating
        // the model instead of painting. The in-world camera is untouched;
        // only modelYaw/modelPitch (used purely for our preview) changes.
        draggingModel = true;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (btn != 0) return super.mouseDragged(mx, my, btn, dx, dy);

        if (painting) {
            PreviewArea area = previewArea();
            if (area.contains((int) mx, (int) my)) {
                BodyRegion region = resolveRegion(area, (int) mx, (int) my);
                if (region != null) paintRegion(region);
            }
            return true;
        }

        if (draggingModel) {
            modelYaw += (float) dx * 1.2f;
            modelYaw = wrapDegrees(modelYaw);
            modelPitch -= (float) dy * 0.6f;
            modelPitch = Math.max(-35f, Math.min(35f, modelPitch));
            return true;
        }

        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        painting = false;
        draggingModel = false;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        if (mx >= panelX()) {
            brushRadius = Math.max(1, Math.min(8, brushRadius + (int) Math.signum(amount)));
            return true;
        }
        return super.mouseScrolled(mx, my, amount);
    }

    // -- Painting logic -----------------------------------------------------------

    /**
     * Maps a resolved body region to a fixed grid cell (matching
     * WhiteSkinManager's UV layout) and applies a brush stroke there.
     */
    private void paintRegion(BodyRegion region) {
        int[] gridCenter = region.gridCenter(modelYaw);
        getLocalData().paintBrush(gridCenter[0], gridCenter[1], brushRadius, currentColor);

        long now = System.currentTimeMillis();
        if (now - lastPaintMs >= 50) {
            lastPaintMs = now;
            sendStroke(gridCenter[0], gridCenter[1], brushRadius, currentColor);
        }
    }

    /**
     * Works out which body region the cursor is over, purely as fractions
     * of the fixed preview rectangle - this avoids any dependency on the
     * exact internal pixel math InventoryScreen.drawEntity uses to size the
     * model, which keeps hit-testing stable regardless of game version.
     */
    private BodyRegion resolveRegion(PreviewArea area, int mx, int my) {
        float fx = (mx - area.x1) / (float) (area.x2 - area.x1); // 0 (left) .. 1 (right)
        float fy = (my - area.y1) / (float) (area.y2 - area.y1); // 0 (top)  .. 1 (bottom)

        // Vertical bands: head / body+arms / legs.
        if (fy < 0.30f) {
            return (fx > 0.30f && fx < 0.70f) ? BodyRegion.HEAD : null; // narrow head column
        } else if (fy < 0.62f) {
            if (fx < 0.32f)      return BodyRegion.ARM_LEFT_SCREEN;
            else if (fx > 0.68f) return BodyRegion.ARM_RIGHT_SCREEN;
            else                 return BodyRegion.BODY;
        } else if (fy < 0.95f) {
            return (fx < 0.5f) ? BodyRegion.LEG_LEFT_SCREEN : BodyRegion.LEG_RIGHT_SCREEN;
        }
        return null;
    }

    private boolean handleColorPick(double mx, double my) {
        Tab[] tabs = Tab.values();
        int px = panelX();
        int paletteY = 6 + 2 * (TAB_H + 2) + 6;
        int[] colors = activeColors();

        for (int i = 0; i < colors.length; i++) {
            int cx2 = px + 2 + (i % COLS) * SWATCH;
            int cy2 = paletteY + (i / COLS) * SWATCH;
            if (mx >= cx2 && mx < cx2 + SWATCH - 1 && my >= cy2 && my < cy2 + SWATCH - 1) {
                currentColor = colors[i];
                return true;
            }
        }
        return false;
    }

    // -- Network --------------------------------------------------------------------

    private void sendStroke(int cx, int cy, int radius, int color) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(cx);
        buf.writeInt(cy);
        buf.writeInt(radius);
        buf.writeInt(color);
        ClientPlayNetworking.send(ChameleonNetwork.PAINT_STROKE, buf);
    }

    // -- Helpers ----------------------------------------------------------------------

    private int panelX()  { return this.width - PANEL_W(); }
    private int PANEL_W() { return Math.min(140 + COLS * SWATCH, this.width / 3); }

    /** Fixed rectangle the 3D character preview is drawn and hit-tested in. */
    private PreviewArea previewArea() {
        int margin = 24;
        int x1 = margin;
        int x2 = panelX() - 10;
        int y1 = margin + 20;
        int y2 = this.height - 50;
        // Guard against degenerate sizes on very small windows.
        if (x2 <= x1 + 20) x2 = x1 + 20;
        if (y2 <= y1 + 20) y2 = y1 + 20;
        return new PreviewArea(x1, y1, x2, y2);
    }

    private PaintData getLocalData() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) return PlayerPaintStore.getPaint(mc.player.getUuid());
        return new PaintData();
    }

    private int[] activeColors() {
        return switch (activeTab) {
            case MECHA -> MECHA; case BASIC -> BASIC; case NATURE -> NATURE;
            case SKIN  -> SKIN;  case PASTEL-> PASTEL; case NEON  -> NEON;
            case DARK  -> DARK;  case EARTH -> EARTH;
        };
    }

    private String tabShort(Tab t) {
        return switch (t) {
            case MECHA -> "MCH"; case BASIC -> "BSC"; case NATURE -> "NAT";
            case SKIN  -> "SKN"; case PASTEL-> "PST"; case NEON  -> "NEO";
            case DARK  -> "DRK"; case EARTH -> "ERT";
        };
    }

    private static float wrapDegrees(float deg) {
        deg %= 360f;
        if (deg > 180f) deg -= 360f;
        if (deg < -180f) deg += 360f;
        return deg;
    }

    @Override public boolean shouldPause()     { return false; }
    @Override public boolean shouldCloseOnEsc(){ return true;  }

    // -- Small value types -------------------------------------------------------------

    private record PreviewArea(int x1, int y1, int x2, int y2) {
        boolean contains(int x, int y) { return x >= x1 && x < x2 && y >= y1 && y < y2; }
    }

    /**
     * Screen-space regions resolved from where the mouse is over the
     * preview. *_SCREEN suffixed regions are re-mapped to the model's
     * actual left/right arm or leg depending on the current yaw, since
     * spinning the model past +/-90 degrees swaps which side faces the
     * camera.
     */
    private enum BodyRegion {
        HEAD, BODY, ARM_LEFT_SCREEN, ARM_RIGHT_SCREEN, LEG_LEFT_SCREEN, LEG_RIGHT_SCREEN;

        /**
         * Returns the {gridX, gridY} cell center to paint, matching
         * WhiteSkinManager's inner-layer UV layout. Handles the
         * front/back swap (yaw beyond +/-90 degrees) and the left/right
         * mirror that comes with it.
         */
        int[] gridCenter(float yawDegrees) {
            boolean facingAway = Math.abs(yawDegrees) > 90f; // back of the model towards us
            boolean mirrored   = facingAway; // left/right swap once spun past the back

            switch (this) {
                case HEAD: return new int[]{ 4, 4 };
                case BODY: return new int[]{ 12, 6 };
                case ARM_LEFT_SCREEN:
                    return mirrored ? new int[]{ 20, 6 } : new int[]{ 24, 6 };
                case ARM_RIGHT_SCREEN:
                    return mirrored ? new int[]{ 24, 6 } : new int[]{ 20, 6 };
                case LEG_LEFT_SCREEN:
                    return mirrored ? new int[]{ 20, 18 } : new int[]{ 24, 18 };
                case LEG_RIGHT_SCREEN:
                    return mirrored ? new int[]{ 24, 18 } : new int[]{ 20, 18 };
                default: return new int[]{ 12, 6 };
            }
        }
    }
}
