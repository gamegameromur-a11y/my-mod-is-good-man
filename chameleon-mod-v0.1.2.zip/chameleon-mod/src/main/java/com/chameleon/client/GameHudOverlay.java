package com.chameleon.client;

import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD is only shown while a server game state is actually present.
 *
 * serverPresent flag: becomes true once the first GAME_STATE packet
 * arrives. ChameleonMod's client packet handler sets this when GAME_STATE
 * is received, and it's reset on disconnect.
 */
@Environment(EnvType.CLIENT)
public class GameHudOverlay {

    /** Has at least one GAME_STATE packet arrived from the server? */
    public static boolean serverPresent = false;

    private static final int BAR_W = 200;
    private static final int BAR_H = 8;

    public static void render(DrawContext ctx, MinecraftClient client, float tickDelta) {
        if (!serverPresent) return;
        if (client.player == null || client.options.hudHidden) return;

        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();
        TextRenderer tr = client.textRenderer;

        switch (GameClientState.stateId) {
            case 0, 1 -> renderWaiting(ctx, tr, sw, sh);
            case 2    -> renderCountdown(ctx, tr, sw, sh);
            case 3    -> renderHiding(ctx, tr, sw, sh, client);
            case 4    -> renderSeeking(ctx, tr, sw, sh, client);
            case 5    -> renderEnded(ctx, tr, sw, sh);
        }

        renderCaughtNotice(ctx, tr, sw);
    }

    private static void renderWaiting(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        String line2 = GameClientState.timerSeconds > 0
                ? "\u00a7aGame starts in \u00a7e" + GameClientState.timerSeconds + "s\u00a7a!"
                : "\u00a77Waiting for more players.";
        ctx.drawCenteredTextWithShadow(tr, "\u00a77Waiting for game...", sw / 2, sh - 60, 0xAAAAAA);
        ctx.drawCenteredTextWithShadow(tr, line2, sw / 2, sh - 48, 0xFFFFFF);
    }

    private static void renderCountdown(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        int secs = GameClientState.timerSeconds;
        String num = secs <= 3 ? "\u00a7c" + secs : "\u00a7e" + secs;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(sw / 2f, sh / 2f - 20, 0);
        ctx.getMatrices().scale(3f, 3f, 1f);
        ctx.drawCenteredTextWithShadow(tr, num, 0, 0, 0xFFFFFF);
        ctx.getMatrices().pop();
        ctx.drawCenteredTextWithShadow(tr, "\u00a77Game starting...", sw / 2, sh / 2 + 24, 0xAAAAAA);
    }

    private static void renderHiding(DrawContext ctx, TextRenderer tr, int sw, int sh,
                                      MinecraftClient client) {
        boolean isSeeker = client.player != null &&
                RoleManager.isSeeker(client.player.getUuid());
        ctx.drawTextWithShadow(tr,
                isSeeker ? "\u00a7c\ud83d\udc41 EYES CLOSED" : "\u00a7a\ud83c\udfc3 HIDING PHASE", 8, 8, 0xFFFFFF);
        int secs = GameClientState.timerSeconds;
        renderTimerBar(ctx, sw, 20, Math.min(1f, secs / 60f),
                isSeeker ? 0xFFFF4444 : 0xFF44FF44, formatTime(secs));
        ctx.drawCenteredTextWithShadow(tr,
                isSeeker ? "\u00a77Hiders are getting ready..." : "\u00a77Find a good spot!",
                sw / 2, sh - 40, 0xCCCCCC);
    }

    private static void renderSeeking(DrawContext ctx, TextRenderer tr, int sw, int sh,
                                       MinecraftClient client) {
        boolean isSeeker = client.player != null &&
                RoleManager.isSeeker(client.player.getUuid());
        ctx.drawTextWithShadow(tr,
                isSeeker ? "\u00a7c\ud83c\udff9 SEEKING PHASE" : "\u00a7a\ud83e\udd2b STAY HIDDEN!", 8, 8, 0xFFFFFF);
        int secs = GameClientState.timerSeconds;
        renderTimerBar(ctx, sw, 20, Math.min(1f, secs / 300f),
                isSeeker ? 0xFFFF6644 : 0xFF4488FF, formatTime(secs));
        ctx.drawCenteredTextWithShadow(tr,
                "\u00a7aHiders left: \u00a7f" + GameClientState.hidersAlive +
                " \u00a77/ \u00a7f" + GameClientState.totalHiders,
                sw / 2, 36, 0xFFFFFF);
        if (secs <= 30 && secs > 0)
            ctx.drawCenteredTextWithShadow(tr, "\u00a7c\u26a0 " + secs + "s left!",
                    sw / 2, sh - 40, 0xFF4444);
    }

    private static void renderEnded(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        ctx.fill(sw/2-120, sh/2-30, sw/2+120, sh/2+20, 0xAA000000);
        ctx.drawCenteredTextWithShadow(tr, "\u00a76\ud83c\udfc6 GAME OVER", sw/2, sh/2-22, 0xFFAA00);
        ctx.drawCenteredTextWithShadow(tr,
                GameClientState.winnerText + " \u00a76WINS!", sw/2, sh/2-6, 0xFFFFFF);
    }

    private static void renderCaughtNotice(DrawContext ctx, TextRenderer tr, int sw) {
        if (GameClientState.caughtPlayerName.isEmpty()) return;
        long ago = System.currentTimeMillis() - GameClientState.caughtAt;
        if (ago > 4000) { GameClientState.caughtPlayerName = ""; return; }
        float alpha = ago < 3000 ? 1f : 1f - (ago - 3000) / 1000f;
        int a = (int)(alpha * 200) << 24;
        ctx.drawCenteredTextWithShadow(tr,
                "\u00a7c\ud83d\udca5 \u00a7f" + GameClientState.caughtPlayerName + " \u00a77was caught!",
                sw / 2, 60, a | 0xFFFFFF);
    }

    private static void renderTimerBar(DrawContext ctx, int sw, int y,
                                        float pct, int color, String label) {
        int bx = (sw - BAR_W) / 2;
        ctx.fill(bx-1, y-1, bx+BAR_W+1, y+BAR_H+1, 0xFF111111);
        ctx.fill(bx, y, bx+(int)(pct*BAR_W), y+BAR_H, color);
        ctx.fill(bx+(int)(pct*BAR_W), y, bx+BAR_W, y+BAR_H, 0xFF333333);
        ctx.drawCenteredTextWithShadow(
                MinecraftClient.getInstance().textRenderer,
                "\u00a7f" + label, sw/2, y+BAR_H+3, 0xFFFFFF);
    }

    private static String formatTime(int s) {
        return s >= 60 ? (s/60) + ":" + String.format("%02d", s%60) : s + "s";
    }
}
